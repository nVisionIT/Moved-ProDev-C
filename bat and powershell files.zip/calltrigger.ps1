
Invoke-WebRequest -Uri 'http://www.google.co.za'